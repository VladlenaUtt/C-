#include <iostream>;
#include <ctime>;
#include <limits>;
#include <string> 

int different(int arr[], int size);
void print(int* arr, int size);
int find(int arr[], int len, int seek);
void printseclargest(int arr[], int arr_size);
void pushZerosToEnd(int arr[], int n);

int main()
{
	//10 terviku arvude massiivis m��rata :
	
	const int ARRAY_SIZE = 10;
	int numArr[] = { 352, 785, 500, 0, 566, 145, 45, 123, 78, 666 };
	std::cout << "352, 785, 500, 0, 566, 145, 45, 123, 78, 666 " << std::endl;
	
	int paaris = 0, paaritu = 0, countmax = 0, countmin = 0, keskmine = 0;
	int max = numArr[0];
	int min = numArr[0];
	//paaris ja paaritu arvude hulk;
	for (int i = 0; i < ARRAY_SIZE; i++)
	{
		int arv = numArr[i];
		if (arv % 2 == 0) {
			paaris++;
		}
		else
			paaritu++;
		// 2. maksimaalne/minimaalne element;
		if (max < numArr[i]){
			max = numArr[i];
		countmax = 1;
		}
		else if (max == numArr[i])
			++countmax;

		if (min > numArr[i]){
			min = numArr[i];
		countmin = 1;
	}
		else if (min == numArr[i])
		++countmin;
	
		keskmine += numArr[i];
	}
		std::cout << "Paarisarve " << paaris << " , paaritu arve " << paaritu << std::endl << std::endl;
		std::cout << "Maksimaalne element " << max << std::endl;
		std::cout << "Minimaalne element " << min << std::endl;
		// 3. maksimaalsete/minimaalsete elementide hulk;
		std::cout << "Maksimaalseid elemente massiivis " << countmax << " , minimaalseid elemente massiivis " << countmin << std::endl;

	// 4. maksimaalse/minimaalse elemendi esimene/viimane number;
	std::string smax = std::to_string(max);
	std::string smin = std::to_string(min);
	std::cout << "Maksimaalse elemendi esimene number - " << smax.at(0) << std::endl;
	std::cout << "Maksimaalse elemendi viimane number - " << smax.back() << std::endl;
	std::cout << "Minimaalse elemendi esimene number - " << smin.at(0) << std::endl;
	std::cout << "Minimaalse elemendi viimane number - " << smin.back() << std::endl;

	// 5. esimene minimaalne vahetada kohtadega massiivi esimese elemendiga, aga maksimaalne element massiivi viimase elemendiga;
		std::cout << "Maksimaalse elemendi indeks - " << find(numArr, ARRAY_SIZE, max) << std::endl;
		int x = find(numArr, ARRAY_SIZE, min);
		int y = find(numArr, ARRAY_SIZE, max);
		std::cout << "Minimaalse elemendi indeks - " << find(numArr, ARRAY_SIZE, min) << std::endl;
	std::swap(numArr[0], numArr[x]);
	std::swap(numArr[9], numArr[y]);
	print(numArr, ARRAY_SIZE);

	// 6. elementide keskmine aritmeetiline t�hendus;
	std::cout << "Elementide keskmine aritmeetiline tahendus: " << keskmine / ARRAY_SIZE << std::endl;

	// 7. arvutada v�lja massiivi pooldavate elementide summa peale esimest nulli (null-elemendi olemasolekul);
	numArr[0] = 1;
	int summa = 0, nullelement = 0;
	while (numArr[nullelement++] != 0 && nullelement < ARRAY_SIZE)
		summa += numArr[nullelement];
	std::cout << "Massiivi pooldavate elementide summa peale esimest nulli: " << summa << std::endl << std::endl;

	// 8. m��rata massiivi teine element suuruse j�rgi;
	printseclargest(numArr, ARRAY_SIZE);

	// 9. m��rata massiivi erinevate elementide hulk;
	int diff = different(numArr, ARRAY_SIZE);
	std::cout << "Erinevaid elemente - " << diff << std::endl;
	
	// 10. k�ik nullid viia �le massiivi l�ppu.
	int n = sizeof(numArr) / sizeof(numArr[0]);
	pushZerosToEnd(numArr, n);
	for (int i = 0; i < n; i++)
		std::cout << numArr[i] << " ";
	return 0;
	
}
void pushZerosToEnd(int arr[], int n)
{
	int count = 0;  
	for (int i = 0; i < n; i++)
		if (arr[i] != 0)
			arr[count++] = arr[i]; 
	while (count < n)
		arr[count++] = 0;
}
int find(int arr[], int len, int seek)
{
	for (int i = 0; i < len; i++)
	{
		if (arr[i] == seek) return i;
	}
	return -1;
}
void print(int* arr, int size) {
	std::cout << " { ";
	for (int i = 0; i < size; i++)
		std::cout << arr[i] << (i + 1 < size ? ", " : "");
	std::cout << " }" << std::endl;
}

int different(int arr[], int size)
{
	int res = 1;
	for (int i = 1; i < size; i++) {
		int j = 0;
		for (j = 0; j < i; j++)
			if (arr[i] == arr[j])
				break;
		if (i == j)
			res++;
	}
	return res;
}
void printseclargest(int arr[], int arr_size)
{
	for (int i = arr_size-2; i >= 0; i--) {
		if (arr[i] != arr[arr_size - 1]) {
			printf("Teine maksimaalne element on %d\n", arr[i]);
			return;
		}
	}
}	
