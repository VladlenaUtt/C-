﻿#include <iostream>;
#include <ctime>;

double leibniz(int x);
double nilakantha(int x);

int main()
{
	//1. On antud täisarv N(> 0).Leida 1 + 1 / 2 + 1 / 3 + … + 1 / N
	int N = 0;
	double summa = 0;
	std::cout << "Sisesta nullist suurem taisarv ";
	std::cin >> N;
	for (int i = 1; i < N; i++)
		summa = summa + 1.0 / i;

	std::cout << "1 + 1 / 2 + 1 / 3 + … + 1 / N = " << summa << std::endl;
	//2. Leia π(pii)
	//	π = (4 / 1) - (4 / 3) + (4 / 5) - (4 / 7) + (4 / 9) - (4 / 11) + (4 / 13) - (4 / 15) ..., Leibnizi jada abil
	//	π = 3 + 4 / (2 * 3 * 4) - 4 / (4 * 5 * 6) + 4 / (6 * 7 * 8) - 4 / (8 * 9 * 10) + 4 / (10 * 11 * 12) - 4 / (12 * 13 * 14) ..., Nilakantha jada abil
	int arv = 0;
	std::cout << "Sisesta lylide arv jadas(taisarv), et leida pi ";
	std::cin >> arv;
	std::cout << "Leibnizi jada abil " << leibniz(arv) << std::endl;
	std::cout << "Nilakantha jada abil " << nilakantha(arv) << std::endl;
	//3.   Arva arvu ära.Loo programm, mis valib juhusliku arvu 0 kuni 10, ja pakkub arvata ära.
	//	Tagastab vastus, kas teie arv on suurem või väiksem.Kuvage katsete arv
	srand(time(NULL));
	int secret = rand() % 10 + 1,
		counter = 0, number = 0;
	std::cout << "Sisesta taisarv vahemikus 0 kuni 10 ";
	while (number != secret)
	{
		counter++;
		std::cin >> number;
		if (number >= 0 && number <= 10)
			if (secret == number) {
				std::cout << "Arvasid ara! ";
				break;
			}
			else if (number < secret)
				std::cout << "Sinu arv on tegelikust arvust vaiksem ";
			else
				std::cout << "Sinu arv on tegelikust arvust suurem ";

		std::cout << "Oled teinud " << counter << " katset" << std::endl;
	}
}
// Leida π = (4 / 1) - (4 / 3) + (4 / 5) - (4 / 7) + (4 / 9) - (4 / 11) + (4 / 13) - (4 / 15) ..., Leibnizi jada abil
double leibniz(int x) {
	double pi = 0;
	for (int i = 1, j = 1; i <= x; i++, j = j + 2) {
		if (i % 2 == 0)
			pi = pi + 4.0 / -j;
		else
			pi = pi + 4.0 / j;
	}
	return pi;
}
// Leida π = 3 + 4 / (2 * 3 * 4) - 4 / (4 * 5 * 6) + 4 / (6 * 7 * 8) - 4 / (8 * 9 * 10) + 4 / (10 * 11 * 12) - 4 / (12 * 13 * 14) ..., Nilakantha jada abil
double nilakantha(int x) {
	double pi = 3, s = 1;
	for (int i = 2; i <= x * 2; i += 2) {
		pi = pi + s * (4.0 / (i * (i + 1) * (i + 2.0)));
		s = -s;
	}
	return pi;
}
