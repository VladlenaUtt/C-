#include <iostream>;
#include <ctime>;
#include <limits>;
#include <algorithm>;

void printArray2d(int** arr, int n, int m);
void readArray2d(int** arr, int n, int m);
void transpose(int** arr, int** tr, int n, int m);
bool isSymmetric(int** arr, int n, int m);
bool rows_are_different(int** arr, int n, int m, int row1, int row2);

int main()
{
	//On antud kahem��duline massiiv A (n, n).
	int rows, columns;
	std::cout << "Sisesta ridade arv: ";
	std::cin >> rows;
	std::cout << "Sisesta tulpade arv: ";
	std::cin >> columns;
	int** arr = new int* [rows];
	for (int i = 0; i < rows; ++i) {
		arr[i] = new int[columns];
	}
	readArray2d(arr, rows, columns);
	printArray2d(arr, rows, columns);
	//1. Leida maatriksi k�ikide elementide, ridade ja tulpade summa;
	int sum = 0, maxElement = 0, minElement = 0;
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < columns; j++)
		{
			sum += arr[i][j];
			if (arr[i][j] > maxElement) {
				maxElement = arr[i][j];
			}
			else if (arr[i][j] < maxElement) {
				minElement = arr[i][j];
				}
			}
		}
		std::cout << "Koikide elementide summa: " << sum << std::endl;

		//2. Leida min/max element maatriksis;

		std::cout << "Max element: " << maxElement << std::endl;
		std::cout << "Min element: " << minElement << std::endl;
		//3. Sorteerida maatriksi tulbad suurenemise j�rgi;
		int count = 0, maxrow = 0, max = 0;
		for (int i = 0; i < columns; i++)
		{
			count = 0;
			std::sort(arr[i], arr[i] + columns);
			std::cout << "\t";
			for (int j = 0; j < rows; j++) {
				if (count = arr[i][j] == 0){
					++count;
			}else
					 count;
			}
			max = max < count ? maxrow = i, count : max;
		}
		printArray2d(arr, rows, columns);
		//4. Leida ridade numbrid, kus on k�ige rohkem nulle;
		std::cout << "Ridade numbrid, kus on k�ige rohkem nulle " << maxrow + 1 << std::endl;
		//5. Leida elementide summa peadiagonaalil ja elementide summa peadiagonaali �levalt;
		int x = 0, drow = 1, dcol = 0, y = 0, dmain = 0;
		sum = 0;
		while (x < rows && y < columns)
		{
			sum += arr[x++][y++];
			if (drow < rows)
				dmain += arr[drow++][dcol++];
		}
		std::cout << "Elementide summa peadiagonaalil - " << sum << std::endl;
		//6. Leida elementide summa k�rvalisel diagonaalil ja elementide summa peadiagonaali all poolt;
		int srow = 0, scol = columns - 1, ssum = 0;
		while (srow < rows)
			ssum += arr[srow++][scol--];
		std::cout << "Elementide summa korvalisel diagonaalil: " << ssum << std::endl;
		std::cout << "Elementide summa peadiagonaali all pool: " << dmain << std::endl;
		//7. M��rata, kas maatriks on s�mmeetriline;
		if (isSymmetric(arr, rows, columns)) {
			std::cout << "Yes";
		}
		else
			std::cout << "No";
		return 0;
		//7. M��rata, kas maatriksis on �hesugused read;
		//std::cout << rows_are_different(arr, rows, columns,int row1, int row2);
		//8. Ruuduline maatriks omab saduli kujulise punkti aij, kui aij on minimaalne element i-reas ja max element j-tulbas.
}

		


void readArray2d(int** arr, int n, int m)
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
		{
			printf("A(%d,%d): ", i, j);
			std::cin >> arr[i][j];
		}
}
void printArray2d(int**arr, int n, int m)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			printf("%5i ", arr[i][j]);
		}
		printf("\n");
	}
}
void transpose(int** arr, int** tr, int n, int m)
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			tr[i][j] = arr[j][i];
}


bool isSymmetric(int** arr, int n, int m)
{
	int** tr;
	transpose(arr, tr, n, m);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			if (arr[i][j] != tr[i][j])
				return false;
	return true;
}
bool rows_are_different(int** arr, int n, int m, int row1, int row2) {

	for (int i = 0; arr[row1 - 1][i] && arr[row2 - 1][i]; i++) {
		if (arr[row1 - 1][i] != arr[row2 - 2][i]) {
			return false;
			std::cout << "Yes";
		}
	}
	return true;
	std::cout << "No";
}

