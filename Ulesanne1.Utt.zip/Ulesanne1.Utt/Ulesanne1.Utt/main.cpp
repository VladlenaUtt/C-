﻿
#pragma once
#include <iostream>
#include <cmath>

int main()
{
	//IF ULESANDED
	//1.  x on reaalarv.Leidke reaaltüübi funktsiooni f väärtust
	//	а)  2·sin(x), kui x > 0  ja
	//	b)  6 – x, kui x ≤ 0.
	double x = 0;
	std::cout << "Sisesta reaalarv ";
	std::cin >> x;
	if (x > 0)
		x = 2 * sin(x);
	else
		x = 6 - x;
	std::cout << "f(x) = " << x << std::endl;
	//2.  x on tervik arv.Leidke täisarvu funktsiooni f väärtust
	//	а)  2·x, kui x < –2 või x > 2,
	//	b) –3·x, teisel juhul.
	int y = 0;
	std::cout << "Sisesta taisarv: ";
	std::cin >> y;
	if (y < -2 || y>2)
		y = 2 * y;
	else
		y = -3 * y;
	std::cout << "f(x) =  " << y << std::endl;
	//SWITCH ULESANDED
	//1.  Sisesta klaviatuurilt tervik arv diapasoonist 1 - 7. Väljasta nädala päeva nimetus(1 - "esmaspäev", 2 - "teisipäev", ...)
	int arv = 0;
	std::cout << "Sisesta taisarv vahemikus 1-7 ";
	std::cin >> arv;
	switch (arv)
	{
	case 1:
		std::cout << "esmaspaev" << std::endl;
		break;
	case 2:
		std::cout << "teisipaev" << std::endl;
		break;
	case 3:
		std::cout << "kolmapaev" << std::endl;
		break;
	case 4:
		std::cout << "neljapaev" << std::endl;
		break;
	case 5:
		std::cout << "reede" << std::endl;
		break;
	case 6:
		std::cout << "laupaev" << std::endl;
		break;
	case 7:
		std::cout << "pyhapaev" << std::endl;
		break;
	}
	//3.  Sisesta klaviatuurilt kuu number(tervik arv diapasoonist 1 - 12).Väljasta aastaaeg("talv", "kevad", "suvi", "sügis")
	int kuu = 0;
	std::cout << "Sisesta kuu number(1-12) ";
	std::cin >> kuu;
	switch (kuu)
	{
	case 12:
	case 1:
	case 2:
		std::cout << "talv" << std::endl;
		break;
	case 3:
	case 4:
	case 5:
		std::cout << "kevad" << std::endl;
		break;
	case 6:
	case 7:
	case 8:
		std::cout << "suvi" << std::endl;
		break;
	case 9:
	case 10:
	case 11:
		std::cout << "sygis" << std::endl;
		break;
	}
}

