﻿

//Lahenda kolmnurga(*), kui antud kolmnurk tasandil, mille tippude
//koordinaadid on A(xA,yA), B(xB,yB), C(xC,yC).
//(*) Leia: kolmnurga küljed, ümbermõõt ja pindala.


#include <iostream>;
#include <cmath>;

double lengthSide(int x1, int y1, int x2, int y2);
double perimeter(int xA, int yA, int xB, int yB, int xC, int yC);
double area(int xA, int yA, int xB, int yB, int xC, int yC);
bool isRightTriangle(double AB, double BC, double AC);

int main()
{
	int xA = 0, yA = 0, xB = 0, yB = 0, xC = 0, yC = 0;
	double AB = 0, BC = 0, AC = 0;
	std::cout << "Sisesta kolmnurga punktide koordinaadid ";
	std::cout << "\r\nxA: ";
	std::cin >> xA;
	std::cout << "yA: ";
	std::cin >> yA;
	std::cout << "xB: ";
	std::cin >> xB;
	std::cout << "yB: ";
	std::cin >> yB;
	std::cout << "xC: ";
	std::cin >> xC;
	std::cout << "yC: ";
	std::cin >> yC;
	AB = lengthSide(xA, yA, xB, yB);
	AC = lengthSide(xA, yA, xC, yC);
	BC = lengthSide(xB, yB, xC, yC);
	std::cout << "AB pikkus: " << AB;
	std::cout << "\r\nBC pikkus: " << BC;
	std::cout << "\r\nAC pikkus: " << AC;
	std::cout << "\r\nAntud kolmnurga umbermoot: " << perimeter(xA, yA, xB, yB, xC, yC) << std::endl;
	std::cout << "Antud kolmnurga pindala: " << area(xA, yA, xB, yB, xC, yC) << std::endl;
	std::cout << "Kas on taisnurkne kolmnurk: " << (isRightTriangle(AB, BC, AC) ? "Jah" : "Ei") << std::endl;
}

//1. Loo reaalarvu funktsioon lengthSide(x1, y1, x2, y2), mis tagastab joone
//AB pikkust. (xA, yA, xB, yB — reaalarvud).Funktsiooni abil leidke AB, AC,
//BC joonete pikkused, kui on antud 3 - punkti A, B, C.
	double lengthSide(int xA, int yA, int xB, int yB) {
		return sqrt(pow(xA - xB, 2) + pow(yA - yB, 2));
	}
//2. Kasuta lengthSide funktsioon ja loo funktsioon perimeter(xA, yA, xB, yB, xC,yC),
//mis tagastab ABC kolmnurga ümbermõõt punktide koordinatide abil.
	double perimeter(int xA, int yA, int xB, int yB, int xC, int yC) {
		return lengthSide(xA, yA, xB, yB) + lengthSide(xA, yA, xC, yC) + lengthSide(xB, yB, xC, yC);
	}
//3. Kasuta leng ja perim funktsioonid, ja loo realarvu funktsiooni area(xA,yA, xB, yB, xC, yC),
//mis tagastab kolmnurga pindala ABC valemi abil, kus p on poolümbermõõt.
	double area(int xA, int yA, int xB, int yB, int xC, int yC) {
		double s,
			p = perimeter(xA, yA, xB, yB, xC, yC) / 2,
			AB = lengthSide(xA, yA, xB, yB),
			AC = lengthSide(xA, yA, xC, yC),
			BC = lengthSide(xB, yB, xC, yC);
		s = sqrt(p * (p - AB) * (p - AC) * (p - BC));
		return s;
	}
//4. Kas kolmnurk on täisnurkne kolmnurk ? Loo funksiooni isRightTriangle, mis tagastab bool.
	bool isRightTriangle(double AB, double BC, double AC) {
		//Pythagorase teoreem
		return (AB * AB + BC * BC == AC * AC || BC * BC + AC * AC == AB * AB || AB * AB + AC * AC == BC * BC);
	}

